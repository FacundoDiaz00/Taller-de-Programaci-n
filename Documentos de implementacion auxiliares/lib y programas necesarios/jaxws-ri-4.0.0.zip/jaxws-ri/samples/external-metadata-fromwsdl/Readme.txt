This sample demonstrates developing WS without using annotations. The main usecase is to expose
existing implementation as a Web Service without need to have source code of the implementation.

Consider having just binaries of class externalmetadata.fromwsdl.client.BlackboxServiceClient
We would just skip compilation of that class but everything else in this example would remain same.

Refer to the Prerequisites defined in samples/docs/index.html.
We appreciate your feedback, please send it to metro-dev@eclipse.org.
